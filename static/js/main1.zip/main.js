$(function(){


    $("#menu-toggle").click(function(e) {       
        $("#wrapper").toggleClass("active");
    });



   $("#form-total").steps({

        headerTag: "h2",
        bodyTag: "section",
        transitionEffect: "fade",        
        autoFocus: true,
        transitionEffectSpeed: 500,
        titleTemplate : '<div class="title">#title#</div>',
        

        labels: {
            finish : '',
            current:'submit'
            
        }, 


        onStepChanged: function (event, currentIndex, newIndex) {
            if (currentIndex < newIndex) {
                $('.steps li.current').next().removeClass('done');                                  
              }
              var $input = $('#submitvendor');
              if (currentIndex === 0) { //if last step
                
                $('.actions > ul > li:last-child').attr('style', 'display:none');              
               $('ul[aria-label=Pagination] button').remove();
                var $input = $('#vsubmitvendor');
                $input.appendTo($('ul[aria-label=Pagination]'));                
                $input.attr('style', 'display:block');              
               }
               else {               
                //$('ul[aria-label=Pagination] input[value="Submit"]').remove();      
                //$('ul[aria-label=Pagination] input[value="Submit"]').appendTo($('a[href="#finish"]'));        
               }
              
        },
        ***/
              
       onStepChanging: function (event, currentIndex, newIndex) { 

            if (currentIndex === 0) {
            $('ul[aria-label=Pagination] input[value="Submit"]').appendTo($('a[href="#finish"]'));
            }

            var adddoor = $('#adddoor').val();
            var company_ranch_ame = $('#company_branch_name').val();
            var locality = $('#locality').val();
            var state = $('#state').val();
            var pincode = $('#pincode').val();
            var primarycontactname = $('#primarycontactname').val();
            var primary_contact_no= $('#primary_contact_no').val();
            var primary_email = $('#primary_email').val();
            var secondary_contact_name = $('#secondary_contact_name').val();
            var secondary_contact_no = $('#secondary_contact_no').val();
            var secondary_email = $('#secondary_email').val();
            var gstin= $('#gstin').val();
            var uin= $('#uin').val();
            var insurcompany= $('#insurcompany').val();
            var insurno= $('#insurno').val();
            var expirydate= $('#expirydate').val();

            $('#company_branch_name-val').text(company_branch_name);
            $('#adddoor-val').text(adddoor);
            $('#locality-val').text(locality);
            $('#state-val').text(state);
            $('#pincode-val').text(pincode);
            $('#primarycontactname-val').text(primarycontactname);
            $('#primary_contact_no-val').text(primary_contact_no);
            $('#primary_email-val').text(primary_email);
            $('#secondary_contact_name-val').text(secondary_contact_name);
            $('#secondary_contact_no-val').text(secondary_contact_no);
            $('#secondary_email-val').text(secondary_email);
            $('#gstin-val').text(gstin);
            $('#uin-val').text(uin);
            $('#insurcompany-val').text(insurcompany);
            $('#insurno-val').text(insurno);
            $('#expirydate-val').text(expirydate);
                     
            $("#form-register").validate().settings.ignore = ":disabled,:hidden";
            return $("#form-register").valid();
               
        },
        onFinished: function (event, currentIndex) {

                   
            var form = $(this);
            jQuery("#wizard").submit();
            // Submit form input
            form.submit();
        }
    });

    
    
});


   

/*$('table').on('click', '#btdelete', function(e){
    alert("dele");
    $(this).closest('tr').remove()
 })

 $(document).ready(function () { 

    $('#backs').click(function(){
   var mySteps = $('#form-total').steps();
    
    steps_api = mySteps.data('plugin_Steps');


    steps_api.prev();
 });
});
*/


